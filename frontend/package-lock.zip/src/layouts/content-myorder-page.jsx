import MenuProfile from "../components/menu_profile";
import MyOrder from "../components/my_order";

function ContentMyOrderPage(){
    return(
        <>
            <MenuProfile/>
            <MyOrder/>
        </>

    )
}

export default ContentMyOrderPage;