import MenuProfile from "../components/menu_profile";
import OrderHistory from "../components/order_history";

function ContentTransacPage(){
    return(
        <>
            <MenuProfile/>
            <OrderHistory/>
        </>
    )
  
}

export default ContentTransacPage;