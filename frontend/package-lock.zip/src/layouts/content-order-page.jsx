/* eslint-disable no-unused-vars */
/* eslint-disable react-hooks/rules-of-hooks */

import OrderPreview from "../components/order_preview";

function contentOrderPage(){


    return(
        <>
            <OrderPreview/>
        </>
    );

}

export default contentOrderPage;