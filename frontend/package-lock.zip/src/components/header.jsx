/* eslint-disable no-unused-vars */
// import $             from "jquery";
import { useEffect } from "react";
import Slide from "../components/slide";

function Header(){


    useEffect(()=>{
      
    },[])


    return (
        // header page
        <>
            <Slide/>
        </>
       
    );

}

export default Header;