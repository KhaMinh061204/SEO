function Loading(){
    return (
        <div className="wrap-loading hide">
            <div id="col">
                <div id="img-wrap">
                    <span className="loader"></span>
                </div>
            </div>
        </div>
      );
}

export default Loading;